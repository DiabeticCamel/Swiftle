const prompt = require('prompt-sync')();


let userNumber = prompt("Give me a number between 5 and 10. ");
let number = 0; 
while (number < userNumber) {
  console.log("Are we there yet?");
  number += 1;
} 

/*
let newNumber = 0;
do {
  console.log("Are we there yet?");
  newNumber += 1;
} while (newNumber < userNumber); */
const prompt = require('prompt-sync')();

let userNumber = prompt("How many copies would you like to print? ")
let printCost
let totalCost

if (userNumber >=1000){
  printCost = 0.25;
} else if (userNumber >=750){
  printCost = 0.27;
} else if (userNumber >=500){
  printCost = 0.28;
} else if (userNumber >=0){
  printCost = 0.30;
} else 
  printCost = 0;

if (isNaN(userNumber)){
console.log("Thats not a number!")
} else {
totalCost = userNumber * printCost;
console.log(userNumber + " copies cost $" + totalCost)
}



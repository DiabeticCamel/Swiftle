const prompt = require('prompt-sync')();

let userInput = prompt("Enter your text for it to be formatted: ");
const charLimit = 6; // Set the character limit per line

let currentLine = "";
let currentLineLength = 0;
let formattedText = "";

const words = userInput.split(" ");

for (let i = 0; i < words.length; i++) {
  const word = words[i];
  const wordLength = word.length;

  if (currentLineLength + wordLength > charLimit) {
    formattedText += currentLine + "\n";
    currentLine = " ".repeat(charLimit - currentLineLength) + word;
    currentLineLength = wordLength;
  } else {
    currentLine += word + " ";
    currentLineLength += wordLength + 1; // +1 for the space
  }
}

formattedText += currentLine; // Add the last line

console.log(formattedText);



//for (let i = 1; counter <= 15; i += 1) {
//  if (i % 3 == 0 && i % 5 == 0) {
//    console.log("FizzBuzz");
//  } else if (i % 3 == 0) {
//    console.log("Fizz");
//  } else if (i % 5 == 0) {
//    console.log("Buzz");
//  } else {
//    console.log(counter)
//  }
//} 

const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const prevMonthBtn = document.getElementById("prevMonth");
const nextMonthBtn = document.getElementById("nextMonth");
const monthYearElement = document.getElementById("monthYear");
const calendarTable = document.getElementById("calendarTable");

let currentMonth = new Date().getMonth();
let currentYear = new Date().getFullYear();

function updateCalendar() {
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

  monthYearElement.textContent = `${months[currentMonth]} ${currentYear}`;
  let day = 1;

  for (let i = 0; i < 6; i++) {
    const row = calendarTable.insertRow();
    for (let j = 0; j < 7; j++) {
      if (i === 0 && j < firstDayOfMonth) {
        const cell = row.insertCell();
        cell.textContent = "";
      } else if (day > lastDayOfMonth) {
        break;
      } else {
        const cell = row.insertCell();
        cell.textContent = day;
        day++;
      }
    }
  }
}

prevMonthBtn.addEventListener("click", () => {
  if (currentMonth === 0) {
    currentMonth = 11;
    currentYear--;
  } else {
    currentMonth--;
  }
  clearCalendar();
  updateCalendar();
});

nextMonthBtn.addEventListener("click", () => {
  if (currentMonth === 11) {
    currentMonth = 0;
    currentYear++;
  } else {
    currentMonth++;
  }
  clearCalendar();
  updateCalendar();
});

function clearCalendar() {
  while (calendarTable.rows.length > 1) {
    calendarTable.deleteRow(1);
  }
}

function updateCalendar() {
  const today = new Date();
  const currentMonthStart = new Date(currentYear, currentMonth, 1);
  const firstDayOfMonth = currentMonthStart.getDay();
  const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

  monthYearElement.textContent = `${months[currentMonth]} ${currentYear}`;
  let day = 1;

  for (let i = 0; i < 6; i++) {
    const row = calendarTable.insertRow();
    for (let j = 0; j < 7; j++) {
      const cell = row.insertCell();
      if ((i === 0 && j < firstDayOfMonth) || day > lastDayOfMonth) {
        cell.textContent = "";
      } else {
        cell.textContent = day;
        if (currentYear === today.getFullYear() && currentMonth === today.getMonth() && day === today.getDate()) {
          cell.style.backgroundColor = "green"; 
        } else if (currentYear === today.getFullYear() && currentMonth === today.getMonth() && day < today.getDate()) {
          cell.textContent = "X"; 
        }
        day++;
      }
    }
  }

  calendarTable.deleteRow(0);
}
window.onload = function() {
  updateCalendar();
};

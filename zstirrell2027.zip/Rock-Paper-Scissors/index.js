const prompt = require('prompt-sync')();

let userInput = prompt("Pick Rock (R), Paper (P), or Scissors (S): ");
let computer = Math.floor(Math.random() * 3) + 1;

if (computer == 1) {
  computer = "r"
} else if (computer == 2) {
  computer = "p"
} else {
  computer = "s"
}

if (userInput.toLowerCase() == "r" && computer == "s") {
  console.log("You win! Rock beats Scissors.");
} else if (userInput.toLowerCase() == "p" && computer == "r") {
  console.log("You win! Paper beats Rock.");
} else if (userInput.toLowerCase() == "s" && computer == "p") {
  console.log("You win! Scissors beats Paper.");
} else if (userInput.toLowerCase() == "r" && computer == "p") {
  console.log("You lose! Paper beats Rock.");
} else if (userInput.toLowerCase() == "p" && computer == "s") {
  console.log("You lose! Scissors beats Paper.");
} else if (userInput.toLowerCase() == "s" && computer == "r") {
  console.log("You lose! Rock beats Scissors.");
} else if (userInput.toLowerCase() == "r" && computer == "r") {
  console.log("It's a tie!");
} else if (userInput.toLowerCase() == "p" && computer == "p") {
  console.log("It's a tie!");
} else if (userInput.toLowerCase() == "s" && computer == "s") {
  console.log("It's a tie!");
} else {
  console.log("Thats not rock, paper, or scissors!");
}

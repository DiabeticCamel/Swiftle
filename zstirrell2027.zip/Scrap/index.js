
for(let i = 0; i <= 12; i += 2) {
  console.log(i)
  if(i === 12) {
    i = 0
  }
}
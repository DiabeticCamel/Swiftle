const prompt = require('prompt-sync')();

let workHours = prompt("How many hours did you work? ")
let hourlyWage = prompt("How much do you earn per hour? ")
let overtimeHours
let overtimeEarn
let totalWage = (workHours * hourlyWage) 
let netWage = totalWage - (totalWage * 0.2)

if (isNaN(hourlyWage) || isNaN(workHours)) {
  console.log("Your hourly wage or hours worked is not a number!")
} else if (workHours <= -1 || hourlyWage <= -1) {
      console.log("Your work hours or your hourly wage is less than 0!")
} else if (workHours <= 40){
      console.log("Your gross pay is $" + totalWage)
      console.log("Your net wages are $" + netWage)
  } else if (workHours >= 40){
      overtimeHours = workHours - 40;
      overtimeEarn = overtimeHours * (hourlyWage * 1.5);
      workHours = workHours - overtimeHours
      totalWage = (workHours * hourlyWage) + overtimeEarn ;
      netWage = totalWage - (totalWage * 0.2)
      console.log("Your gross pay is $" + totalWage)
      console.log("Your net wages are $" + netWage)
  }
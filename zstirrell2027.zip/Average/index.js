const prompt = require('prompt-sync')();

let sumOfScores = 0;
let numOfScores = 0;
let score;

while (score !== -1) {
  score = parseInt(prompt("What grade do you want to enter or -1: "));
  if (score !== -1) {
    sumOfScores += score;
    numOfScores += 1;
  }
}

if (numOfScores > 0) {
  let average = sumOfScores / numOfScores;
  console.log("The average of your scores is " + average);
} else {
  console.log("No scores were entered.");
}

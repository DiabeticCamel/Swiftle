const prompt = require('prompt-sync')();

console.log("This is a simple would you rather program. \nPlease answer the questions with the first letter of the option \nyou would rather do.\n\nWould you rather watch only scary movies (s) or only comedies (c)");

let question = prompt("for the rest of your life? ");

if (question.toLowerCase() == "c") {
  console.log("\nFunny guy")
} else if (question.toLowerCase() == "s") {
 console.log("\n      .-.\n     (o.o)\n      |=|\n     __|__\n   / .=|=. \\ \n  /  .=|=.  \\ \n  \\  .=|=.  /\n   \\ (_=_) / \n    (:| |:)\n     || ||\n     () ()\n     || ||\n     || ||\n    ==   ==")
} else {
  console.log("\nPlease enter a valid answer.")
}

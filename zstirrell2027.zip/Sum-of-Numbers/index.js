const prompt = require('prompt-sync')();

let num1 = parseInt(prompt("Pick the first number: "))
let num2 = parseInt(prompt("Pick the second number: "))
let num1Clone = num1

if(isNaN(num1) || isNaN(num2)) {
  console.log("One of your numbers is not a number!")
} else if (num1 > num2) {
  console.log("The first number is smaller than the second number")
} else {
for(let counter = num1 +1; counter != num2 + 1; counter +=1) {
  end = num1 += counter 
}
  console.log("The sum of the numbers between " + num1Clone + " and " + num2 + " is " + end);
}

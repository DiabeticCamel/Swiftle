const prompt = require('prompt-sync')();

let fact = parseInt(prompt("Pick a number you want to find the factorial of: "))


for(let counter = fact -1; counter != 1; counter -=1) {
  fact *= counter
}
console.log(fact);

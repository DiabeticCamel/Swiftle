const prompt = require('prompt-sync')();

let userInput = prompt("Pick a number you want multiples up to: ");

for(let counter = 1; counter <= userInput; counter += 1){
    console.log(counter + " " + (counter * 2) + " " + (counter * 3) + " " + (counter * 4) + " " + (counter * 5));
}



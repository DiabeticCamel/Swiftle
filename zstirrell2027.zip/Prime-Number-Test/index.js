const prompt = require('prompt-sync')();

let userNum = parseInt(prompt("What number would you like to prime check? "))

let div = userNum;

do{
  div -=1;
} while (userNum % div !=0);

if (div == 1){
  console.log(userNum + " is a prime number")
} else {
  console.log(userNum + " is not a prime number")
}
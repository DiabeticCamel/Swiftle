const prompt = require('prompt-sync')();

let userNum = prompt("Enter a number: ");

for (let counter = 1; counter <= userNum; counter +=1) {
  if (counter % 2 == 0) {
    console.log(counter + " is even");
  } else {
    console.log(counter + " is odd");
  }
}

const songTitles = [

// Taylor Swift
    "Tim McGraw",
    "Picture To Burn",
    "Teardrops On My Guitar - Radio Single Remix ",
    "A Place In This World",
    "Cold As You",
    "The Outside",
    "Tied Together With A Smile",
    "Stay Beautiful",
    "Should’ve Said No",
    "Mary’s Song (Oh My My My)",
    "Our Song",
    "I’m Only Me When I’m With You",
    "Invisible",
    "A Perfectly Good Heart",
    "Teardrops On My Guitar - Pop Version",

// Fearless
    "Fearless",
    "Fifteen",
    "Love Story",
    "Hey Stephen",
    "White Horse",
    "You Belong With Me",
    "Breathe",
    "Tell Me Why",
    "You’re Not Sorry",
    "The Way I Loved You",
    "Forever & Always",
    "The Best Day",
    "Change",
    "Jump Then Fall",
    "Untouchable",
    "Forever & Always (Piano Version)",
    "Come In With The Rain",
    "Superstar",
    "The Other Side Of The Door ",
    "Today Was A Fairytale",
    "You All Over Me",
    "Mr. Perfectly Fine",
    "We Were Happy",
    "That’s When",
    "Don’t You",
    "Bye Bye Baby",
    "If This Was A Movie",

// Speak Now
    "Mine",
    "Sparks Fly",
    "Back To December",
    "Speak Now",
    "Dear John",
    "Mean",
    "The Story Of Us",
    "Never Grow Up",
    "Enchanted",
    "Better Than Revenge",
    "Innocent",
    "Haunted",
    "Last Kiss",
    "Long Live",
    "Ours",
    "Superman",
    "Electric Touch",
    "When Emma Falls In Love",
    "I Can See You",
    "Castles Crumbling",
    "Foolish One",
    "Timeless",


// RED
    "State Of Grace",
    "Red",
    "Treacherous",
    "I Knew You Were Trouble",
    "22",
    "I Almost Do",
    "We Are Never Ever Getting Back Together",
    "Stay Stay Stay",
    "The Last Time",
    "Holy Ground",
    "Sad Beautiful Tragic",
    "The Lucky One",
    "Everything Has Changed",
    "Starlight",
    "Begin Again",
    "The Moment I Knew",
    "Come Back…Be Here",
    "Girl At Home",
    "State Of Grace (Acoustic Version)",
    "Ronan",
    "Better Man",
    "Nothing New",
    "Babe",
    "Message In A Bottle",
    "I Bet You Think About Me",
    "Forever Winter",
    "Run",
    "The Very First Night",
    "All Too Well (10 Minute Version)",

// 1989
    "Welcome To New York",
    "Blank Space",
    "Style",
    "Out Of The Wood",
    "All You Had To Do Was Stay",
    "Shake It Off",
    "I Wish You Would",
    "Bad Blood",
    "Wildest Dreams",
    "How You Get The Girl",
    "This Love",
    "I Know Places",
    "Clean",
    "Wonderland",
    "You Are In Love",
    "New Romantics",
    "”Slut!”",
    "Say Don’t Go",
    "Now That We Don’t Talk",
    "Suburban Legends",
    "Is It Over Now?",

// reputation
    "...Ready For It?",
    "End Game",
    "I Did Something Bad",
    "Don’t Blame Me",
    "Delicate",
    "Look What You Made Me Do",
    "So It Goes…",
    "Gorgeous",
    "Getaway Car",
    "King Of My Heart",
    "Dancing With Our Hands Tied",
    "Dress",
    "This Is Why We Can’t Have Nice Things",
    "Call It What You Want",
    "New Year’s Day",

// folklore
    "the 1",
    "cardigan",
    "the last great american dynasty",
    "exile",
    "my tears ricochet",
    "mirrorball",
    "seven",
    "august",
    "this is me trying",
    "illicit affairs",
    "invisible string",
    "mad woman",
    "epiphany",
    "betty",
    "peace",
    "hoax",
    "the lakes - bonus track",

// evermore
    "willow",
    "champagne problems",
    "gold rush",
    "’tis the damn season",
    "tolerate it",
    "no body, no crime",
    "happiness",
    "dorothea",
    "coney island",
    "ivy",
    "cowboy like me",
    "long story short",
    "marjorie",
    "closure",
    "evermore",
    "right where you left me - bonus track",
    "it’s time to go - bonus track",

// Midnights
    "Lavender Haze",
    "Maroon",
    "Anti-Hero",
    "Snow On The Beach",
    "You’re On Your Own Kid",
    "Midnight Rain",
    "Question…?",
    "Vigilante Shit",
    "Bejeweled",
    "Labyrinth",
    "Karma",
    "Sweet Nothing",
    "Mastermind",
    "The Great War",
    "Bigger Than The Whole Sky",
    "Paris",
    "High Infidelity",
    "Glitch",
    "Would’ve, Could’ve, Should’ve",
    "Dear Reader",
    "Hits Different",
    "Snow On The Beach",
    "Karma",

]


function autocomplete(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function (e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) {
          return false;
      }
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
          /*check if the item starts with the same letters as the text field value:*/
          // if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          // check if the song title contains the query
          if (arr[i].toUpperCase().includes(val.toUpperCase())) {
              /*create a DIV element for each matching element:*/
              b = document.createElement("DIV");
              /*make the matching letters bold:*/
              b.innerHTML = arr[i]
              /*insert a input field that will hold the current array item's value:*/
              b.innerHTML += '<input type="hidden" value="' + arr[i] + '">';
              /*execute a function when someone clicks on the item value (DIV element):*/
              b.addEventListener("click", function (e) {
                  /*insert the value for the autocomplete text field:*/
                  inp.value = this.getElementsByTagName("input")[0].value;
                  /*close the list of autocompleted values,
                  (or any other open lists of autocompleted values:*/
                  closeAllLists();
              });
              if (a.childElementCount < 5) // only show top 5 results
                  a.appendChild(b);
          }
      }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function (e) {
      var x = document.getElementById(this.id + "autocomplete-list");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
          /*If the arrow DOWN key is pressed,
          increase the currentFocus variable:*/
          currentFocus++;
          /*and and make the current item more visible:*/
          addActive(x);
      } else if (e.keyCode == 38) { //up
          /*If the arrow UP key is pressed,
          decrease the currentFocus variable:*/
          currentFocus--;
          /*and and make the current item more visible:*/
          addActive(x);
      } else if (e.keyCode == 13) {
          /*If the ENTER key is pressed, prevent the form from being submitted,*/
          e.preventDefault();
          if (currentFocus > -1) {
              /*and simulate a click on the "active" item:*/
              if (x) x[currentFocus].click();
              document.getElementById("guess-button").click()
          }
      }
      if (arr.includes(inp.value)) {
          document.getElementById("guess-button").disabled = false;
      } else {
          document.getElementById("guess-button").disabled = true;
      }
  });

  function addActive(x) {
      /*a function to classify an item as "active":*/
      if (!x) return false;
      /*start by removing the "active" class on all items:*/
      removeActive(x);
      if (currentFocus >= x.length) currentFocus = 0;
      if (currentFocus < 0) currentFocus = (x.length - 1);
      /*add class "autocomplete-active":*/
      x[currentFocus].classList.add("autocomplete-active");
  }

  function removeActive(x) {
      /*a function to remove the "active" class from all autocomplete items:*/
      for (var i = 0; i < x.length; i++) {
          x[i].classList.remove("autocomplete-active");
      }
  }

  function closeAllLists(elmnt) {
      /*close all autocomplete lists in the document,
      except the one passed as an argument:*/
      var x = document.getElementsByClassName("autocomplete-items");
      for (var i = 0; i < x.length; i++) {
          if (elmnt != x[i] && elmnt != inp) {
              x[i].parentNode.removeChild(x[i]);
          }
      }
  }
  /*execute a function when someone clicks in the document:*/
  document.addEventListener("click", function (e) {
      closeAllLists(e.target);
      if (arr.includes(inp.value)) {
          document.getElementById("guess-button").disabled = false;
      } else {
          document.getElementById("guess-button").disabled = true;
      }
  });
}

autocomplete(document.getElementById("search-input"), songTitles);
const prompt = require('prompt-sync')();

let userGrade = prompt("What percent did you earn? Just type the number. ");
let letter;

if (userGrade >= 101) {
  console.log("Error: number is higher than 100")
  letter = "undefined"
} else if (userGrade >=97) {
  letter = "A+!";
} else if (userGrade >=93) {
  letter = "A!";
} else if (userGrade >=90) {
  letter = "A-!";
} else if (userGrade >=87) {
  letter = "B+!"
} else if (userGrade >=82) {
  letter = "B"
} else if (userGrade >=80) {
  letter = "B-"
} else if (userGrade >=77) {
  letter = "C+"
} else if (userGrade >=73) {
  letter = "C"
} else if (userGrade >=70) {
  letter = "C-"
} else if (userGrade >=67) {
  letter = "D+"
} else if (userGrade >=62) {
  letter = "D"
} else if (userGrade >=60) {
  letter = "D-"
} else if (userGrade >=0) {
  letter = "F"
} else if (userGrade <=-1) {
  console.log("Error: number is lower than 0")
  number = "undefined"
}

if (letter === "A+") {
  console.log("You earned an " + letter);
} else if (letter === "A") {
  console.log("You earned an " + letter);
} else if (letter === "A-") {
  console.log("You earned an " + letter);
} else if (letter === "undefined") {
  console.log("Input a number from 0-100");
} else if (letter === "F") {
  console.log("You earned an " + letter);
} else {
  console.log("You earned a " + letter);
}
